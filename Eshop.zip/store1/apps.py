from django.apps import AppConfig


class Store1Config(AppConfig):
    name = 'store1'
